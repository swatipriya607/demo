import java.util.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import shopping.CD;
public class ShoppingServlet extends HttpServlet 
{
  public void init(ServletConfig conf) throws ServletException
  {
    super.init(conf);
   }
   public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
   {
     HttpSession sessiion=req.getSession(true);
	 if(session==null)
	 {
	    res.sendRedirect("http://localhost:8080/error.html");
     }
     Vector buylist=(Vector)session.getValue("shopping.shoppingcart");
     String action=req.getParameter("action");
     if(!action.equals("CHECKOUT")) {
           	 if(action.equals("DELETE")) {
			     String del=req.getParameter("delindex");
				 int d=(new Integer(del)).intValue();
				 buyliat.removeElementAt(d);
				 }
			else if(action.equals("ADD")) {
                  boolean match=false;
                  CD aCD=getCD(req);
                  if (buylist==null) {
                          buylist=new Vector();
                          buylist.addElement(aCD);
                     }
                   else {
                         for(int i=0;i<buylist.size();i++) {
                            CD cd=(CD) buylist.elementAt(i);
						     if(cd.getAlbum().equals(aCD.getAlbum())) {
							 cd.setQuantity(cd.getQuantity()+aCD.getQuantity());
							 buylist.setElementAt(cd,i);
							 match=true;
						     }
							}
						if(!match)
							buylist.addElementAt(cd,i);
						}
				}
			    session.putValue("shopping.shoppingcart",buylist);
				String url="/EShop.jsp";
				ServletContext sc=getServletContext();
				RequestDispatcher rd=sc.getRequestDispatcher(url);
				rd.forward(req,res);
			}
				else if(action.equals("CHECKOUT")) {
						float total=0;
						for(int i=0;i<buylist.size();i++) {
							CD anOrder=(CD) buylist.elementAt(i);
							float price=anOrder.getPrice();
							int qty=anOrder.getQuantity();
							total +=(price*qty);
						}
						total+=0.005;
						String amount=new Float(total).toString();
						int n=amount.indexOf('.');
						amount=amount.substring(0,n+3);
						req.setAttribute("amount",amount);
						String url="/jsp/shopping/Checkout.jsp";
						ServletContext sc=getServletContext();
						RequestDispatcher rd=sc.getRequestDispatcher(url);
						rd.forward(req,res);
					}
				}
private CD getCD(HttpServletRequest req) {
					String myCD = req.getParameter("CD");
					String qty=req.getParameter("qty");
					StringTokenizer t=new StringTokenizer(myCD,"|");
					String album=t.nextToken();
					String artist=t.nextToken();
					String country=t.nextToken();
					String price=t.nextToken();
					price=price.replace('$',' ').trim();
					CD cd=new CD();
					cd.setAlbum(album);
					cd.setArtist(artist);
					cd.setCountry(country);
					cd.setPrice((new Float(price)).floatValue());
					cd.setQuantity((new Integer(qty)).intValue());
					return cd;
				}						
}